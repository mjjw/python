# DoD DT&E DOE + MCDA Toolkit (Python)

A service-agnostic starter framework for planning and analyzing **Developmental Test & Evaluation (DT&E)** experiments and **Multi-Criteria Decision Analysis (MCDA)**. It is designed to be adapted by Army, Navy, Air Force, Space Force, Marine Corps, Coast Guard, and joint program teams. It is not an official DoD standard, approved test plan, or substitute for service policy, safety review, engineering judgment, or an accredited statistical/operational test organization.

## What is included

- **DOE planning:** full-factorial designs, one-factor-at-a-time (OFAT) plans, a three-factor Box–Behnken response-surface design, random run order, replication, blocking, and run identifiers.
- **DOE analysis:** factor coding, OLS model fitting, coefficient table, ANOVA, residual diagnostics, and predicted response summaries.
- **MCDA:** weighted-sum model, TOPSIS ranking, AHP pairwise-weight estimation with consistency ratio, benefit/cost criteria handling, missing-data checks, and Monte Carlo weight sensitivity.
- **Auditability:** input templates, explicit criterion direction, weight validation, CSV outputs, seed-controlled randomization, and test cases.
- **Example:** a synthetic, unclassified illustrative test campaign and alternatives/criteria data.
- **Optional Streamlit UI:** local browser interface for a basic MCDA comparison.

## Installation

Requires Python 3.10 or newer.

### Windows PowerShell
```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -e .
pip install -e ".[ui,dev]"   # optional UI and tests
```

### Linux / macOS
```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -e .
pip install -e ".[ui,dev]"   # optional UI and tests
```

For a disconnected/air-gapped network, build and validate a wheelhouse on an approved connected machine matching the target OS, Python version, and CPU architecture:
```bash
python -m pip download -r requirements-offline.txt -d wheelhouse
```
Then transfer the approved wheelhouse using your organization's authorized media process and install:
```bash
python -m pip install --no-index --find-links wheelhouse .
```
Create `requirements-offline.txt` from `requirements.txt` and pin versions after validation. Do not transfer software or data into a classified enclave without required scanning, authorization, and media handling.

## Quick start

From the project root:

```bash
# Generate a randomized 2-level full factorial design
python -m dod_dte.cli doe --method full-factorial --factors examples/factors.csv --replicates 2 --seed 42 --out outputs/design.csv

# Analyze observed response data (the input CSV must include the design columns and a response column)
python -m dod_dte.cli analyze --data examples/doe_results.csv --response mission_score --factors sensor_mode,processing_mode,environment --out outputs/analysis

# Rank alternatives with weighted sum and TOPSIS
python -m dod_dte.cli mcda --data examples/mcda_alternatives.csv --criteria examples/criteria.csv --weights examples/weights.csv --out outputs/mcda

# Run tests
pytest
```

If you install the package with `pip install -e .`, the console command `dod-dte` is also available; use `dod-dte --help`.

## DOE methods and when to use them

| Method | Appropriate use | Important limitation |
|---|---|---|
| Full factorial | Screening interactions across a modest number of factors and levels | Run count grows exponentially: product of levels × replicates |
| OFAT | Simple troubleshooting or a familiar baseline comparison | Does not estimate interactions efficiently; not recommended as the only DOE for interacting systems |
| Box–Behnken (3 factors) | Fit a second-order response surface around a safe operating region | Requires three continuous factors and a defensible range; this implementation is specifically the 3-factor design |
| Blocked/replicated plan | Reduce nuisance variation across days, sites, lots, operators, or configurations | Blocking must be defined before test execution; it does not remove the need to randomize within feasible constraints |

**Plan before testing:** define objectives and hypotheses; primary/secondary measures; operationally meaningful effect sizes; factors and feasible levels; nuisance variables; safety and authorization constraints; sample size/power; acceptance criteria; data capture; randomization restrictions; and analysis plan. If test order cannot be fully randomized, record the restriction and use blocks or split-plot methods with a statistician.

## DOE factor input

`examples/factors.csv`:
```csv
factor,levels
sensor_mode,baseline|enhanced
processing_mode,standard|optimized
environment,nominal|stress
```
For full factorial, `levels` are separated with `|`. Numeric factors can use explicit levels such as `temperature:20|30|40`; factor names should be simple column names. This initial version treats levels as categorical values for design generation. For response-surface methods, provide numeric factors and values directly in code.

## DOE analysis input

A CSV should have one row per run and:
- factor columns named exactly as in the design;
- one numeric response column, e.g. `mission_score`;
- optional `block` or metadata columns (not automatically modeled unless listed as a factor).

The analysis uses an ordinary least squares model with main effects and all pairwise interactions, when the number of observations permits. It adds a quadratic term for numeric factors only when requested. Interpret p-values in context; model hierarchy, multiple testing, non-normal errors, heteroskedasticity, censoring, and repeated measures may require specialized models.

Example:
```python
import pandas as pd
from dod_dte.doe import analyze_ols

df = pd.read_csv("examples/doe_results.csv")
result = analyze_ols(df, response="mission_score",
                     factors=["sensor_mode", "processing_mode", "environment"])
print(result["coefficients"])
print(result["anova"])
result["coefficients"].to_csv("outputs/coefficients.csv")
```

## MCDA inputs

`mcda_alternatives.csv`: one row per alternative, one column per criterion, numeric scores only.
`criteria.csv`:
```csv
criterion,direction,description
effectiveness,benefit,mission effectiveness score
cost,cost,estimated lifecycle cost
schedule,benefit,schedule confidence score
```
Direction must be `benefit` (higher is better) or `cost` (lower is better).
`weights.csv`:
```csv
criterion,weight
effectiveness,0.5
cost,0.3
schedule,0.2
```
Weights must be non-negative and sum to 1 (within tolerance); the toolkit can normalize them when explicitly asked. Scores must be defined on defensible, documented scales. Avoid mixing raw dollars, probabilities, ordinal judgments, and performance scores without a documented transformation.

## MCDA methods

- **Weighted sum:** normalize each criterion to [0,1], invert cost criteria, then calculate the weighted sum. Easy to explain; rankings can be sensitive to normalization and criteria independence assumptions.
- **TOPSIS:** normalize criteria vectors, apply weights, and rank by relative closeness to a constructed ideal. Useful as a comparison, but the result depends on candidate set and scale.
- **AHP:** derive weights from a reciprocal pairwise-comparison matrix and report Saaty consistency ratio. A consistency ratio above 0.10 is a common review flag, not an automatic invalidation.
- **Monte Carlo sensitivity:** sample weights around baseline weights using a Dirichlet distribution, then estimate how often each alternative ranks first. This is a sensitivity diagnostic, not a probability that an alternative will succeed. Criteria scores can also be uncertain; extend the simulation if score uncertainty is material.

## Recommended DT&E workflow

1. **Frame the decision:** capability gap, decision owner, alternatives/configurations, use conditions, mission threads, constraints, and the decision to be supported.
2. **Define measures:** MOEs (mission-level effectiveness), MOPs (technical performance), KPPs/KSA thresholds where applicable, reliability/availability/maintainability, suitability, interoperability, cybersecurity, safety, cost, schedule, and data-quality measures as relevant.
3. **Build the DOE:** identify controllable factors, levels, nuisance factors, blocks, responses, hypotheses, effect sizes, and test constraints. Decide how run order will be randomized.
4. **Review statistical adequacy:** estimate sample size/power using realistic variance and minimum meaningful effect; plan missing data, outliers, repeated measures, and stopping rules.
5. **Execute and record:** preserve run ID, configuration/software version, operator/site, environmental conditions, calibration, timestamps, deviations, failures, and data lineage.
6. **Analyze:** inspect data quality and residuals; fit a model aligned to the design; quantify effects and uncertainty; compare against predeclared thresholds; distinguish statistical from operational significance.
7. **MCDA:** define feasible alternatives and criteria; document rationale for weights, scoring scales, and criterion direction; run multiple methods; examine sensitivity and rank reversals.
8. **Independent review:** have test, engineering, safety, cybersecurity, cost, operational, and decision stakeholders review assumptions and results. Preserve source data, code version, run seed, decisions, and approvals.

## DoD-wide tailoring

This framework deliberately does **not** hard-code a service's acquisition, test, safety, cybersecurity, or approval process. Tailor it to the current DoD 5000-series policy and applicable service instructions, TEMP/test strategy, test organization requirements, range rules, data governance, classification markings, export-control restrictions, and program-specific decision authority. Confirm current authoritative requirements with your acquisition/test office; this repository is a technical starter, not policy guidance.

## Security and data handling

- Use synthetic or approved unclassified data in the example.
- Do not place CUI, classified, export-controlled, ITAR, privacy, or operationally sensitive data in an unapproved environment.
- Validate all inputs and output locations before use.
- Pin dependencies, scan packages and artifacts, document software bill of materials, and follow local STIG/hardening and authorization requirements.
- Do not use rankings as an autonomous acquisition decision. Preserve decision-maker accountability and explain tradeoffs.

## Project layout

```text
dod_dte/
  doe.py       DOE design generation and OLS analysis
  mcda.py      weighted sum, TOPSIS, AHP, sensitivity
  cli.py       command-line interface
  app.py       optional Streamlit interface
examples/
  factors.csv
  doe_results.csv
  mcda_alternatives.csv
  criteria.csv
  weights.csv
tests/
  test_doe.py
  test_mcda.py
```

## Known limits / extension points

- This is a starter framework, not a validated test-analysis product.
- Full-factorial designs are categorical-level designs; fractional factorial, D-optimal, split-plot, reliability growth, sequential/adaptive DOE, Bayesian optimization, censored-time-to-event, and mixed-effects models are not implemented in v1.
- Box–Behnken support is limited to three numeric factors.
- OLS is intended for an initial analysis; confirm assumptions and use a suitable model for binary/count/survival/repeated-measures responses.
- AHP matrix input is provided as a Python API; the CLI uses a supplied weight file.
