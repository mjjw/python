# Drag and Drop Data Analysis Tool (Java)

A lightweight Java Swing-based GUI tool to load CSV files via drag-and-drop and visualize data using charts.

## Features
- Drag-and-drop CSV support
- Data table viewer
- Auto-generated line charts
- Uses Apache Commons CSV and JFreeChart

## Requirements
- Java 11+
- Maven

## How to Run

```bash
mvn compile exec:java -Dexec.mainClass="Main"
```

Or package as a JAR:

```bash
mvn package
java -cp target/DragDropDataTool-1.0.jar Main
```
