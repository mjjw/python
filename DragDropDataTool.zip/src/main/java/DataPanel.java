import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.datatransfer.DataFlavor;
import java.awt.dnd.*;
import java.io.*;
import java.util.*;
import org.apache.commons.csv.*;
import org.jfree.chart.*;
import org.jfree.chart.plot.*;
import org.jfree.data.category.DefaultCategoryDataset;

public class DataPanel extends JPanel {

    private JTable table;
    private DefaultTableModel model;
    private JPanel chartPanel;

    public DataPanel() {
        setLayout(new BorderLayout());
        model = new DefaultTableModel();
        table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        chartPanel = new JPanel(new BorderLayout());
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, scrollPane, chartPanel);
        splitPane.setDividerLocation(500);
        add(splitPane, BorderLayout.CENTER);
        enableFileDrop();
    }

    private void enableFileDrop() {
        new DropTarget(this, new DropTargetAdapter() {
            public void drop(DropTargetDropEvent evt) {
                try {
                    evt.acceptDrop(DnDConstants.ACTION_COPY);
                    java.util.List<File> droppedFiles = (java.util.List<File>)
                            evt.getTransferable().getTransferData(DataFlavor.javaFileListFlavor);
                    for (File file : droppedFiles) {
                        if (file.getName().endsWith(".csv")) {
                            loadCSV(file);
                        }
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });
    }

    private void loadCSV(File file) {
        try (Reader in = new FileReader(file)) {
            CSVParser parser = CSVFormat.DEFAULT.withFirstRecordAsHeader().parse(in);
            List<String> headers = parser.getHeaderNames();
            model.setColumnIdentifiers(headers.toArray());
            model.setRowCount(0);
            for (CSVRecord record : parser) {
                Vector<String> row = new Vector<>();
                for (String header : headers) {
                    row.add(record.get(header));
                }
                model.addRow(row);
            }
            SwingUtilities.invokeLater(this::updateChart);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void updateChart() {
        if (model.getColumnCount() < 2) return;
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        try {
            for (int i = 0; i < model.getRowCount(); i++) {
                String x = model.getValueAt(i, 0).toString();
                for (int j = 1; j < model.getColumnCount(); j++) {
                    String yStr = model.getValueAt(i, j).toString();
                    double y = Double.parseDouble(yStr);
                    dataset.addValue(y, model.getColumnName(j), x);
                }
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Only numeric columns can be charted.");
            return;
        }

        JFreeChart chart = ChartFactory.createLineChart(
                "Data Chart",
                model.getColumnName(0),
                "Values",
                dataset,
                PlotOrientation.VERTICAL,
                true,
                true,
                false
        );

        ChartPanel chartComp = new ChartPanel(chart);
        chartPanel.removeAll();
        chartPanel.add(chartComp, BorderLayout.CENTER);
        chartPanel.validate();
    }
}
