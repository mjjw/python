# Drag and Drop Data Analysis Tool (Python)

A simple Python-based GUI tool to drag and drop CSV files and visualize the data.

## Features
- Drag-and-drop CSV loading (via file picker)
- Displays CSV in a table
- Auto-plots numeric columns using Matplotlib

## Requirements
- Python 3.8+
- pandas
- matplotlib

## Installation

```bash
pip install pandas matplotlib
```

## Usage

```bash
python src/main.py
```
