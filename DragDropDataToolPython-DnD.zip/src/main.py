import tkinter as tk
from tkinter import ttk, messagebox
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import os

class DataAnalysisApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Drag-and-Drop Data Analysis Tool (Python)")
        self.geometry("1000x600")
        self.data = None

        self.create_widgets()
        self.register_drop()

    def create_widgets(self):
        self.tree = ttk.Treeview(self)
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.chart_frame = tk.Frame(self)
        self.chart_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        self.drop_label = tk.Label(self, text="Drag CSV file here", bg="lightgray", height=2)
        self.drop_label.pack(fill=tk.X)

    def register_drop(self):
        # Windows specific drag and drop handling
        self.drop_label.drop_target_register(tk.DND_FILES)
        self.drop_label.dnd_bind("<<Drop>>", self.handle_drop)

    def handle_drop(self, event):
        file_path = event.data.strip('{}')  # Clean up Windows paths
        if os.path.isfile(file_path) and file_path.endswith('.csv'):
            self.load_csv(file_path)

    def load_csv(self, file_path):
        try:
            self.data = pd.read_csv(file_path)
            self.display_table()
            self.plot_chart()
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load CSV: {e}")

    def display_table(self):
        self.tree.delete(*self.tree.get_children())
        self.tree["columns"] = list(self.data.columns)
        self.tree["show"] = "headings"

        for col in self.data.columns:
            self.tree.heading(col, text=col)

        for _, row in self.data.iterrows():
            self.tree.insert("", "end", values=list(row))

    def plot_chart(self):
        for widget in self.chart_frame.winfo_children():
            widget.destroy()

        if self.data.shape[1] < 2:
            return

        x = self.data.iloc[:, 0]
        fig, ax = plt.subplots(figsize=(5, 4), dpi=100)

        for col in self.data.columns[1:]:
            try:
                y = pd.to_numeric(self.data[col])
                ax.plot(x, y, label=col)
            except ValueError:
                continue

        ax.set_title("Line Chart")
        ax.set_xlabel(self.data.columns[0])
        ax.set_ylabel("Values")
        ax.legend()

        canvas = FigureCanvasTkAgg(fig, master=self.chart_frame)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

if __name__ == "__main__":
    try:
        import tkinterdnd2 as tkdnd
        app = DataAnalysisApp()
        app.tk.call('package', 'require', 'tkdnd')
        app.mainloop()
    except ImportError:
        messagebox.showerror("Dependency Error", "Install tkinterdnd2: pip install tkinterdnd2")
