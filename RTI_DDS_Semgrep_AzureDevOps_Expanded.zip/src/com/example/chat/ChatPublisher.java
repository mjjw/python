package com.example.chat;

import com.rti.dds.domain.DomainParticipant;
import com.rti.dds.domain.DomainParticipantFactory;
import com.rti.dds.publication.Publisher;
import com.rti.dds.publication.DataWriter;

public class ChatPublisher {
    public static void main(String[] args) {
        DomainParticipant participant = DomainParticipantFactory.get_instance().create_participant(
            0, DomainParticipantFactory.PARTICIPANT_QOS_DEFAULT, null, 0);

        Publisher publisher = participant.create_publisher(DomainParticipant.PUBLISHER_QOS_DEFAULT, null, 0);

        DataWriter writer = publisher.create_datawriter(null, Publisher.DATAWRITER_QOS_DEFAULT, null, 0);

        // Your chat publish logic here
    }
}
