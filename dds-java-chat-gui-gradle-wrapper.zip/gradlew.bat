@echo off
set VERSION=8.7
set DISTRIBUTION_URL=https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip
if not exist ".gradle-wrapper" mkdir .gradle-wrapper
curl -sL %DISTRIBUTION_URL% -o .gradle-wrapper\gradle.zip
tar -xf .gradle-wrapper\gradle.zip -C .gradle-wrapper
.gradle-wrapper\gradle-%VERSION%\bin\gradle %*