"""Service-agnostic DT&E DOE and MCDA starter toolkit."""
__version__ = "1.0.0"
