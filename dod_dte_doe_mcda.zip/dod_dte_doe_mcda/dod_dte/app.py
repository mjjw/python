"""Optional local Streamlit UI for quick MCDA exploration."""
import streamlit as st
import pandas as pd
from .mcda import weighted_sum, topsis, monte_carlo_weight_sensitivity

st.set_page_config(page_title="DT&E MCDA Workbench", layout="wide")
st.title("DT&E MCDA Workbench")
st.caption("Exploratory decision support only. Document scoring assumptions and obtain independent review.")

st.markdown("Upload an alternatives CSV with an `alternative` column and numeric criterion columns.")
uploaded = st.file_uploader("Alternatives CSV", type=["csv"])
if uploaded:
    raw = pd.read_csv(uploaded)
    if "alternative" not in raw.columns:
        st.error("CSV must include an 'alternative' column.")
        st.stop()
    scores = raw.set_index("alternative")
    st.subheader("Scores")
    st.dataframe(scores, use_container_width=True)
    criteria = list(scores.columns)
    st.subheader("Criterion directions and weights")
    cols = st.columns(min(3, max(1, len(criteria))))
    directions, weights = {}, {}
    default_weight = 1 / len(criteria)
    for i, c in enumerate(criteria):
        with cols[i % len(cols)]:
            directions[c] = st.selectbox(f"{c}: direction", ["benefit", "cost"], key=f"d_{c}")
            weights[c] = st.number_input(f"{c}: weight", min_value=0.0, max_value=1.0,
                                         value=float(default_weight), step=0.05, key=f"w_{c}")
    total = sum(weights.values())
    st.write(f"Weight total: **{total:.3f}**")
    if st.button("Calculate rankings"):
        if total <= 0:
            st.error("At least one weight must be positive.")
        else:
            normalized = {k: v / total for k, v in weights.items()}
            st.subheader("Weighted sum")
            st.dataframe(weighted_sum(scores, normalized, directions), use_container_width=True)
            st.subheader("TOPSIS")
            st.dataframe(topsis(scores, normalized, directions), use_container_width=True)
            st.subheader("Weight sensitivity")
            st.dataframe(monte_carlo_weight_sensitivity(scores, normalized, directions), use_container_width=True)
