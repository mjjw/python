from __future__ import annotations
import argparse
from pathlib import Path
import json
import pandas as pd
from .doe import read_factor_spec, full_factorial, ofat_design, box_behnken_3factor, analyze_ols, write_analysis
from .mcda import load_mcda_inputs, weighted_sum, topsis, monte_carlo_weight_sensitivity


def main():
    parser = argparse.ArgumentParser(prog="dod-dte", description="DT&E DOE and MCDA starter toolkit")
    sub = parser.add_subparsers(dest="command", required=True)

    p_doe = sub.add_parser("doe", help="Generate a DOE plan")
    p_doe.add_argument("--method", choices=["full-factorial", "ofat"], default="full-factorial")
    p_doe.add_argument("--factors", required=True, help="CSV with factor,levels columns")
    p_doe.add_argument("--replicates", type=int, default=1)
    p_doe.add_argument("--seed", type=int, default=42)
    p_doe.add_argument("--block-size", type=int, default=None)
    p_doe.add_argument("--out", required=True)

    p_an = sub.add_parser("analyze", help="Analyze a numeric response with OLS")
    p_an.add_argument("--data", required=True)
    p_an.add_argument("--response", required=True)
    p_an.add_argument("--factors", required=True, help="Comma-separated factor column names")
    p_an.add_argument("--quadratic", action="store_true")
    p_an.add_argument("--no-interactions", action="store_true")
    p_an.add_argument("--out", required=True, help="Output directory")

    p_mcda = sub.add_parser("mcda", help="Rank alternatives with weighted sum, TOPSIS and sensitivity")
    p_mcda.add_argument("--data", required=True)
    p_mcda.add_argument("--criteria", required=True)
    p_mcda.add_argument("--weights", required=True)
    p_mcda.add_argument("--out", required=True)
    p_mcda.add_argument("--iterations", type=int, default=5000)
    p_mcda.add_argument("--seed", type=int, default=42)

    args = parser.parse_args()
    if args.command == "doe":
        factors = read_factor_spec(args.factors)
        if args.method == "full-factorial":
            design = full_factorial(factors, replicates=args.replicates, seed=args.seed, block_size=args.block_size)
        else:
            design = ofat_design(factors, seed=args.seed)
        out = Path(args.out)
        out.parent.mkdir(parents=True, exist_ok=True)
        design.to_csv(out, index=False)
        print(f"Wrote {len(design)} runs to {out}")
    elif args.command == "analyze":
        df = pd.read_csv(args.data)
        result = analyze_ols(df, args.response, [x.strip() for x in args.factors.split(",") if x.strip()],
                             interactions=not args.no_interactions, quadratic=args.quadratic)
        write_analysis(result, args.out)
        print(json.dumps(result["metrics"], indent=2))
        print(f"Wrote analysis outputs to {args.out}")
    elif args.command == "mcda":
        scores, directions, weights = load_mcda_inputs(args.data, args.criteria, args.weights)
        out = Path(args.out)
        out.mkdir(parents=True, exist_ok=True)
        ws = weighted_sum(scores, weights, directions)
        tp = topsis(scores, weights, directions)
        sens = monte_carlo_weight_sensitivity(scores, weights, directions, iterations=args.iterations, seed=args.seed)
        ws.to_csv(out / "weighted_sum.csv")
        tp.to_csv(out / "topsis.csv")
        sens.to_csv(out / "weight_sensitivity.csv")
        print("Weighted-sum ranking:")
        print(ws[["weighted_score", "rank"]].to_string())
        print("\nTOPSIS ranking:")
        print(tp.to_string())
        print(f"\nWrote MCDA outputs to {out}")


if __name__ == "__main__":
    main()
