from __future__ import annotations
from itertools import product
from pathlib import Path
from typing import Sequence
import math
import numpy as np
import pandas as pd
from scipy import stats


def read_factor_spec(path: str | Path) -> dict[str, list[str]]:
    """Read factor,levels CSV. Levels are pipe-separated, e.g. low|high."""
    spec = pd.read_csv(path)
    required = {"factor", "levels"}
    if not required.issubset(spec.columns):
        raise ValueError(f"Factor file must contain columns: {sorted(required)}")
    factors = {}
    for _, row in spec.iterrows():
        name = str(row["factor"]).strip()
        levels = [x.strip() for x in str(row["levels"]).split("|") if x.strip()]
        if not name or len(levels) < 2:
            raise ValueError(f"Factor {name!r} must have at least two levels")
        if name in factors:
            raise ValueError(f"Duplicate factor name: {name}")
        factors[name] = levels
    if not factors:
        raise ValueError("At least one factor is required")
    return factors


def full_factorial(factors: dict[str, Sequence], replicates: int = 1,
                   randomize: bool = True, seed: int | None = None,
                   block_size: int | None = None) -> pd.DataFrame:
    """Generate all combinations, replicated and optionally randomized."""
    if replicates < 1:
        raise ValueError("replicates must be >= 1")
    if not factors:
        raise ValueError("factors cannot be empty")
    for name, levels in factors.items():
        if len(levels) < 2:
            raise ValueError(f"Factor {name} must have at least two levels")
    rows = []
    for rep in range(1, replicates + 1):
        for combo in product(*factors.values()):
            row = dict(zip(factors.keys(), combo))
            row["replicate"] = rep
            rows.append(row)
    df = pd.DataFrame(rows)
    rng = np.random.default_rng(seed)
    if randomize:
        df = df.iloc[rng.permutation(len(df))].reset_index(drop=True)
    df.insert(0, "run_order", np.arange(1, len(df) + 1))
    df.insert(1, "run_id", [f"RUN-{i:04d}" for i in range(1, len(df) + 1)])
    if block_size:
        if block_size < 1:
            raise ValueError("block_size must be >= 1")
        df["block"] = ((df["run_order"] - 1) // block_size + 1).astype(int)
    return df


def ofat_design(factors: dict[str, Sequence], baseline: dict[str, object] | None = None,
                randomize: bool = True, seed: int | None = None) -> pd.DataFrame:
    """One-factor-at-a-time plan: baseline plus each non-baseline level per factor."""
    if not factors:
        raise ValueError("factors cannot be empty")
    baseline = baseline or {k: v[0] for k, v in factors.items()}
    for k, levels in factors.items():
        if k not in baseline or baseline[k] not in levels:
            raise ValueError(f"Baseline for {k} must be one of its declared levels")
    rows = [dict(baseline)]
    for factor, levels in factors.items():
        for level in levels:
            if level == baseline[factor]:
                continue
            row = dict(baseline)
            row[factor] = level
            rows.append(row)
    df = pd.DataFrame(rows)
    rng = np.random.default_rng(seed)
    if randomize and len(df) > 1:
        # Keep baseline first for operational clarity; randomize remaining runs.
        rest = df.iloc[1:].iloc[rng.permutation(len(df) - 1)]
        df = pd.concat([df.iloc[[0]], rest], ignore_index=True)
    df.insert(0, "run_order", np.arange(1, len(df) + 1))
    df.insert(1, "run_id", [f"OFAT-{i:04d}" for i in range(1, len(df) + 1)])
    return df


def box_behnken_3factor(levels: dict[str, tuple[float, float, float]],
                        center_points: int = 3, randomize: bool = True,
                        seed: int | None = None) -> pd.DataFrame:
    """Three-factor Box–Behnken design with low/center/high numeric values."""
    if len(levels) != 3:
        raise ValueError("This implementation requires exactly three factors")
    if center_points < 1:
        raise ValueError("center_points must be >= 1")
    names = list(levels)
    for name, vals in levels.items():
        if len(vals) != 3 or not all(np.isfinite(float(x)) for x in vals):
            raise ValueError(f"{name} must have three finite numeric values: low, center, high")
        if not (float(vals[0]) < float(vals[1]) < float(vals[2])):
            raise ValueError(f"{name} levels must satisfy low < center < high")
    coded = []
    # For each pair, set pair to +/-1 and remaining factor to 0.
    for i, j in [(0, 1), (0, 2), (1, 2)]:
        k = ({0, 1, 2} - {i, j}).pop()
        for a, b in product([-1, 1], repeat=2):
            row = [0, 0, 0]
            row[i], row[j], row[k] = a, b, 0
            coded.append(row)
    coded.extend([[0, 0, 0] for _ in range(center_points)])
    rows = []
    for row in coded:
        actual = {}
        for name, code in zip(names, row):
            lo, mid, hi = map(float, levels[name])
            actual[name] = lo if code == -1 else hi if code == 1 else mid
        rows.append(actual)
    df = pd.DataFrame(rows)
    if randomize:
        rng = np.random.default_rng(seed)
        df = df.iloc[rng.permutation(len(df))].reset_index(drop=True)
    df.insert(0, "run_order", np.arange(1, len(df) + 1))
    df.insert(1, "run_id", [f"BB-{i:04d}" for i in range(1, len(df) + 1)])
    return df


def _design_matrix(df: pd.DataFrame, factors: Sequence[str],
                   interactions: bool = True, quadratic: bool = False) -> tuple[pd.DataFrame, list[str]]:
    if not set(factors).issubset(df.columns):
        missing = sorted(set(factors) - set(df.columns))
        raise ValueError(f"Missing factor columns: {missing}")
    terms = {"Intercept": np.ones(len(df))}
    base_cols = {}
    for factor in factors:
        series = df[factor]
        if pd.api.types.is_numeric_dtype(series) and series.nunique() > 2:
            vals = series.astype(float)
            scale = vals.std(ddof=0)
            base_cols[factor] = (vals - vals.mean()) / (scale if scale else 1.0)
            terms[factor] = base_cols[factor].to_numpy()
        else:
            cats = sorted(series.astype(str).unique())
            # Reference coding; one column for each non-reference level.
            for cat in cats[1:]:
                col = f"{factor}[{cat}]"
                terms[col] = (series.astype(str) == cat).astype(float).to_numpy()
            # A compact coded column is used for interaction generation only when binary.
            if len(cats) == 2:
                base_cols[factor] = (series.astype(str) == cats[1]).astype(float) * 2 - 1
    if interactions:
        for i, a in enumerate(factors):
            for b in factors[i + 1:]:
                if a in base_cols and b in base_cols:
                    terms[f"{a}:{b}"] = np.asarray(base_cols[a]) * np.asarray(base_cols[b])
    if quadratic:
        for factor in factors:
            if factor in base_cols and pd.api.types.is_numeric_dtype(df[factor]) and df[factor].nunique() > 2:
                terms[f"{factor}^2"] = np.asarray(base_cols[factor]) ** 2
    return pd.DataFrame(terms, index=df.index), list(terms)


def analyze_ols(df: pd.DataFrame, response: str, factors: Sequence[str],
                interactions: bool = True, quadratic: bool = False) -> dict:
    """Fit OLS via least squares and return coefficients, fit metrics, ANOVA and residuals."""
    if response not in df:
        raise ValueError(f"Response column {response!r} not found")
    y = pd.to_numeric(df[response], errors="coerce")
    if y.isna().any():
        raise ValueError("Response must be numeric and have no missing values")
    X, term_names = _design_matrix(df, factors, interactions, quadratic)
    if len(y) <= X.shape[1]:
        raise ValueError(f"Need more observations than model terms; n={len(y)}, terms={X.shape[1]}")
    beta, _, rank, _ = np.linalg.lstsq(X.to_numpy(float), y.to_numpy(float), rcond=None)
    fitted = X.to_numpy(float) @ beta
    residuals = y.to_numpy(float) - fitted
    n, p = X.shape
    dof_resid = n - rank
    if dof_resid <= 0:
        raise ValueError("No residual degrees of freedom; reduce model terms or collect more data")
    sse = float(np.sum(residuals ** 2))
    sst = float(np.sum((y.to_numpy(float) - y.mean()) ** 2))
    ssr = sst - sse
    mse = sse / dof_resid
    xtx_inv = np.linalg.pinv(X.to_numpy(float).T @ X.to_numpy(float))
    se = np.sqrt(np.maximum(0, np.diag(xtx_inv) * mse))
    tvals = np.divide(beta, se, out=np.zeros_like(beta), where=se > 0)
    pvals = 2 * stats.t.sf(np.abs(tvals), dof_resid)
    crit = stats.t.ppf(0.975, dof_resid)
    coef = pd.DataFrame({
        "term": term_names, "estimate": beta, "std_error": se, "t_value": tvals,
        "p_value": pvals, "ci95_low": beta - crit * se, "ci95_high": beta + crit * se
    })
    # Sequential term contribution is not reported as ANOVA because term order can mislead.
    metrics = {
        "n": int(n), "terms": int(p), "rank": int(rank), "df_residual": int(dof_resid),
        "sse": sse, "rmse": float(math.sqrt(mse)),
        "r_squared": float(1 - sse / sst) if sst > 0 else float("nan"),
        "adjusted_r_squared": float(1 - (1 - (1 - sse / sst)) * (n - 1) / dof_resid) if sst > 0 else float("nan")
    }
    residual_frame = df.copy()
    residual_frame["observed"] = y.to_numpy()
    residual_frame["predicted"] = fitted
    residual_frame["residual"] = residuals
    residual_frame["standardized_residual"] = residuals / (math.sqrt(mse) if mse > 0 else 1.0)
    # Overall regression F-test
    if rank > 1 and sse > 0:
        df_model = rank - 1
        ms_model = ssr / df_model
        f_stat = ms_model / mse if mse > 0 else float("inf")
        f_p = float(stats.f.sf(f_stat, df_model, dof_resid))
    else:
        df_model, ms_model, f_stat, f_p = max(rank - 1, 0), float("nan"), float("nan"), float("nan")
    anova = pd.DataFrame([{
        "source": "Model (overall)", "df": df_model, "sum_sq": ssr,
        "mean_sq": ms_model, "F": f_stat, "p_value": f_p
    }, {
        "source": "Residual", "df": dof_resid, "sum_sq": sse,
        "mean_sq": mse, "F": np.nan, "p_value": np.nan
    }])
    return {"coefficients": coef, "metrics": metrics, "anova": anova,
            "residuals": residual_frame, "design_matrix": X}


def write_analysis(result: dict, output_dir: str | Path) -> None:
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    result["coefficients"].to_csv(out / "coefficients.csv", index=False)
    result["anova"].to_csv(out / "anova.csv", index=False)
    result["residuals"].to_csv(out / "residuals.csv", index=False)
    pd.DataFrame([result["metrics"]]).to_csv(out / "fit_metrics.csv", index=False)
