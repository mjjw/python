from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd


def _validate_inputs(scores: pd.DataFrame, directions: dict[str, str],
                     weights: dict[str, float] | pd.Series | None = None):
    if scores.empty or len(scores.columns) == 0:
        raise ValueError("Scores table must have at least one alternative and one criterion")
    if scores.index.has_duplicates:
        raise ValueError("Alternative names/index must be unique")
    if scores.columns.has_duplicates:
        raise ValueError("Criterion names must be unique")
    numeric = scores.apply(pd.to_numeric, errors="coerce")
    if numeric.isna().any().any():
        raise ValueError("All alternative criterion scores must be numeric and non-missing")
    if not np.isfinite(numeric.to_numpy(float)).all():
        raise ValueError("Scores must be finite")
    missing = set(scores.columns) - set(directions)
    if missing:
        raise ValueError(f"Missing direction for criteria: {sorted(missing)}")
    bad = {k: v for k, v in directions.items() if k in scores.columns and v not in {"benefit", "cost"}}
    if bad:
        raise ValueError(f"Directions must be benefit or cost: {bad}")
    if weights is not None:
        w = pd.Series(weights, dtype=float).reindex(scores.columns)
        if w.isna().any() or (w < 0).any() or not np.isfinite(w.to_numpy()).all():
            raise ValueError("Weights must be finite, non-negative, and defined for every criterion")
        if w.sum() <= 0:
            raise ValueError("At least one weight must be positive")
    return numeric.astype(float)


def _minmax_normalize(scores: pd.DataFrame, directions: dict[str, str]) -> pd.DataFrame:
    norm = pd.DataFrame(index=scores.index)
    for col in scores.columns:
        lo, hi = scores[col].min(), scores[col].max()
        if hi == lo:
            norm[col] = 1.0
        elif directions[col] == "benefit":
            norm[col] = (scores[col] - lo) / (hi - lo)
        else:
            norm[col] = (hi - scores[col]) / (hi - lo)
    return norm


def weighted_sum(scores: pd.DataFrame, weights: dict[str, float] | pd.Series,
                 directions: dict[str, str], normalize_weights: bool = False) -> pd.DataFrame:
    """Min-max normalize to [0,1], orient all criteria so higher is better, then weighted sum."""
    raw = _validate_inputs(scores, directions, weights)
    w = pd.Series(weights, dtype=float).reindex(raw.columns)
    if normalize_weights:
        if w.sum() <= 0:
            raise ValueError("Weights must sum to > 0")
        w = w / w.sum()
    elif not np.isclose(w.sum(), 1.0, atol=1e-6):
        raise ValueError(f"Weights must sum to 1 (got {w.sum():.6f}); set normalize_weights=True to normalize")
    norm = _minmax_normalize(raw, directions)
    contributions = norm.mul(w, axis=1)
    result = pd.DataFrame({
        "alternative": raw.index.astype(str),
        "weighted_score": contributions.sum(axis=1),
    }).set_index("alternative")
    result["rank"] = result["weighted_score"].rank(ascending=False, method="min").astype(int)
    result = result.sort_values(["rank", "weighted_score"], ascending=[True, False])
    return result.join(contributions.add_prefix("contrib_"), how="left")


def topsis(scores: pd.DataFrame, weights: dict[str, float] | pd.Series,
           directions: dict[str, str], normalize_weights: bool = False) -> pd.DataFrame:
    """TOPSIS with vector normalization and benefit/cost-aware ideal points."""
    raw = _validate_inputs(scores, directions, weights)
    w = pd.Series(weights, dtype=float).reindex(raw.columns)
    if normalize_weights:
        w = w / w.sum()
    elif not np.isclose(w.sum(), 1.0, atol=1e-6):
        raise ValueError(f"Weights must sum to 1 (got {w.sum():.6f})")
    denom = np.sqrt((raw ** 2).sum(axis=0)).replace(0, 1)
    weighted = raw.div(denom, axis=1).mul(w, axis=1)
    ideal, anti = {}, {}
    for col in raw.columns:
        if directions[col] == "benefit":
            ideal[col], anti[col] = weighted[col].max(), weighted[col].min()
        else:
            ideal[col], anti[col] = weighted[col].min(), weighted[col].max()
    ideal_df = pd.Series(ideal)
    anti_df = pd.Series(anti)
    d_pos = np.sqrt(((weighted - ideal_df) ** 2).sum(axis=1))
    d_neg = np.sqrt(((weighted - anti_df) ** 2).sum(axis=1))
    closeness = d_neg / (d_pos + d_neg).replace(0, np.nan)
    result = pd.DataFrame({"alternative": raw.index.astype(str),
                           "topsis_closeness": closeness.to_numpy()}).set_index("alternative")
    result["rank"] = result["topsis_closeness"].rank(ascending=False, method="min").astype(int)
    return result.sort_values(["rank", "topsis_closeness"], ascending=[True, False])


def ahp_weights(pairwise: pd.DataFrame) -> dict:
    """Estimate AHP priorities from principal eigenvector and Saaty consistency ratio."""
    if pairwise.shape[0] != pairwise.shape[1] or list(pairwise.index) != list(pairwise.columns):
        raise ValueError("Pairwise matrix must be square with matching row/column labels in the same order")
    A = pairwise.to_numpy(float)
    if not np.isfinite(A).all() or (A <= 0).any():
        raise ValueError("AHP comparisons must be positive finite numbers")
    if not np.allclose(A, 1 / A.T, atol=1e-5):
        raise ValueError("AHP matrix must be reciprocal (a_ij = 1/a_ji)")
    if not np.allclose(np.diag(A), 1, atol=1e-5):
        raise ValueError("AHP diagonal must be all ones")
    vals, vecs = np.linalg.eig(A)
    idx = int(np.argmax(vals.real))
    lam_max = float(vals[idx].real)
    vec = np.abs(vecs[:, idx].real)
    weights = vec / vec.sum()
    n = len(weights)
    ci = (lam_max - n) / (n - 1) if n > 1 else 0.0
    ri_table = {1: 0.0, 2: 0.0, 3: 0.58, 4: 0.90, 5: 1.12,
                6: 1.24, 7: 1.32, 8: 1.41, 9: 1.45, 10: 1.49}
    ri = ri_table.get(n, 1.49)
    cr = ci / ri if ri else 0.0
    return {"weights": pd.Series(weights, index=pairwise.index, name="weight"),
            "lambda_max": lam_max, "consistency_index": float(ci),
            "random_index": float(ri), "consistency_ratio": float(cr),
            "review_flag": bool(cr > 0.10)}


def monte_carlo_weight_sensitivity(scores: pd.DataFrame, base_weights: dict[str, float] | pd.Series,
                                  directions: dict[str, str], iterations: int = 5000,
                                  concentration: float = 80, seed: int | None = 42) -> pd.DataFrame:
    """Sample perturbed weights and report rank-first frequency; not a success probability."""
    raw = _validate_inputs(scores, directions, base_weights)
    w = pd.Series(base_weights, dtype=float).reindex(raw.columns)
    if (w < 0).any() or w.sum() <= 0:
        raise ValueError("Base weights must be non-negative and sum to > 0")
    w = w / w.sum()
    if iterations < 1 or concentration <= 0:
        raise ValueError("iterations and concentration must be positive")
    norm = _minmax_normalize(raw, directions)
    rng = np.random.default_rng(seed)
    alpha = np.maximum(w.to_numpy() * concentration, 1e-6)
    samples = rng.dirichlet(alpha, size=iterations)
    vals = norm.to_numpy(float) @ samples.T
    winners = np.argmax(vals, axis=0)
    first = pd.Series(winners).value_counts(normalize=True)
    out = pd.DataFrame({"alternative": raw.index.astype(str)})
    out["rank_first_frequency"] = [float(first.get(i, 0.0)) for i in range(len(raw))]
    out["rank_first_percent"] = out["rank_first_frequency"] * 100
    out = out.sort_values("rank_first_frequency", ascending=False).set_index("alternative")
    out.attrs["iterations"] = iterations
    out.attrs["concentration"] = concentration
    out.attrs["seed"] = seed
    return out


def load_mcda_inputs(alternatives_path: str | Path, criteria_path: str | Path,
                     weights_path: str | Path) -> tuple[pd.DataFrame, dict[str, str], dict[str, float]]:
    alternatives = pd.read_csv(alternatives_path)
    if "alternative" not in alternatives.columns:
        raise ValueError("Alternatives CSV must contain an 'alternative' column")
    alternatives = alternatives.set_index("alternative")
    criteria = pd.read_csv(criteria_path)
    if not {"criterion", "direction"}.issubset(criteria.columns):
        raise ValueError("Criteria CSV must contain criterion,direction")
    directions = dict(zip(criteria["criterion"].astype(str), criteria["direction"].astype(str).str.lower()))
    weights_df = pd.read_csv(weights_path)
    if not {"criterion", "weight"}.issubset(weights_df.columns):
        raise ValueError("Weights CSV must contain criterion,weight")
    weights = dict(zip(weights_df["criterion"].astype(str), pd.to_numeric(weights_df["weight"], errors="raise")))
    if set(alternatives.columns) != set(directions):
        raise ValueError(f"Alternative criteria {sorted(alternatives.columns)} do not match criteria file {sorted(directions)}")
    return alternatives, directions, weights
