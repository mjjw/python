# DT&E Decision Record Template

## 1. Decision and authority
- Program / system / configuration:
- Decision to be supported:
- Decision owner and date:
- Alternatives considered, including baseline / no-change:
- Applicable test strategy, TEMP, service instructions, range and safety approvals:

## 2. Operational context
- Mission thread / scenario:
- Users, operators, sites, environment, threat or stress conditions (approved level only):
- Constraints, assumptions, exclusions:
- Data classification / CUI status and approved storage location:

## 3. Measures
| Measure | Type (MOE/MOP/KPP/KSA/other) | Operational definition | Unit / scale | Threshold | Objective | Source / collection method |
|---|---|---|---|---|---|---|

## 4. DOE plan
- Hypotheses:
- Primary response(s):
- Factors and levels:
- Nuisance factors and blocks:
- Design type and rationale:
- Randomization restrictions:
- Replication / sample size / power rationale:
- Calibration, configuration control, run ID and data schema:
- Exclusion, missing-data and stopping rules:
- Pre-specified model and diagnostics:

## 5. Results and uncertainty
- Data quality checks:
- Deviations:
- Effect estimates and confidence intervals:
- Residual/model checks:
- Threshold attainment:
- Limitations / threats to validity:

## 6. MCDA
- Criteria and directions:
- Score scales and evidence:
- Weights and rationale / elicitation method:
- Weighted-sum result:
- TOPSIS result:
- Sensitivity / rank reversals:
- Stakeholder disagreements and unresolved assumptions:

## 7. Recommendation and approvals
- Recommendation:
- Key tradeoffs:
- Conditions / risk mitigations:
- Independent review:
- Decision authority disposition:
