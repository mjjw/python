import pandas as pd
from dod_dte.doe import full_factorial, ofat_design, analyze_ols


def test_full_factorial_count():
    d = full_factorial({"a": ["0", "1"], "b": ["x", "y", "z"]}, replicates=2, seed=1)
    assert len(d) == 12
    assert d["run_id"].is_unique
    assert d["run_order"].tolist() == list(range(1, 13))


def test_ofat_count():
    d = ofat_design({"a": ["low", "high"], "b": ["off", "on", "fast"]}, randomize=False)
    assert len(d) == 1 + (2 - 1) + (3 - 1)


def test_ols_returns_metrics():
    df = pd.DataFrame({
        "a": ["low", "low", "high", "high", "low", "low", "high", "high"],
        "b": ["off", "on", "off", "on", "off", "on", "off", "on"],
        "y": [1, 2, 3, 5, 1.2, 2.1, 3.2, 5.1]
    })
    result = analyze_ols(df, "y", ["a", "b"])
    assert "r_squared" in result["metrics"]
    assert len(result["coefficients"]) > 0
