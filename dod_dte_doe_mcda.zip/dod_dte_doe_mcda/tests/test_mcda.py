import pandas as pd
from dod_dte.mcda import weighted_sum, topsis, ahp_weights, monte_carlo_weight_sensitivity


def sample():
    scores = pd.DataFrame({
        "performance": [80, 90, 70],
        "cost": [100, 140, 80],
    }, index=["A", "B", "C"])
    directions = {"performance": "benefit", "cost": "cost"}
    weights = {"performance": 0.6, "cost": 0.4}
    return scores, directions, weights


def test_weighted_sum_and_topsis():
    s, d, w = sample()
    assert weighted_sum(s, w, d).iloc[0]["rank"] == 1
    assert topsis(s, w, d).iloc[0]["rank"] == 1


def test_ahp_consistent_matrix():
    m = pd.DataFrame([[1, 2], [0.5, 1]], index=["a", "b"], columns=["a", "b"])
    out = ahp_weights(m)
    assert abs(out["weights"].sum() - 1) < 1e-8
    assert out["consistency_ratio"] == 0


def test_sensitivity_sums_to_one():
    s, d, w = sample()
    out = monte_carlo_weight_sensitivity(s, w, d, iterations=100, seed=1)
    assert abs(out["rank_first_frequency"].sum() - 1) < 1e-8
