cmake_minimum_required(VERSION 3.10)
project(DragDropMLApp)

set(CMAKE_CXX_STANDARD 17)
find_package(Qt5Widgets REQUIRED)

add_executable(DragDropMLApp main.cpp)
target_link_libraries(DragDropMLApp Qt5::Widgets)
