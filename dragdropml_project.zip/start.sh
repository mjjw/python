#!/bin/bash
set -e

: "${VNC_PASSWORD:=dragdrop}"

if [ ! -f /opt/dragdropml/.vnc/passwd ]; then
  mkdir -p /opt/dragdropml/.vnc
  echo "$VNC_PASSWORD" | x11vnc -storepasswd - /opt/dragdropml/.vnc/passwd
fi

Xvfb :1 -screen 0 1024x768x24 &
fluxbox &
x11vnc -display :1 -rfbauth /opt/dragdropml/.vnc/passwd -forever -shared &
/opt/noVNC/utils/websockify/run --web=/opt/noVNC/ 6901 localhost:5901 &

./DragDropMLApp

wait
